var tree = {
	"A:": {
		"commands": {
			"man": {
				"man":"Format and display the off-line manual pages\n",
				"com":"if(args[0]===''){args[0] = 'man'}\n"+
				"if(exists('A:/commands/'+args[0])){\n"+
				"  printy(readFile('A:/commands/'+args[0]+'/man'));\n"+
				"}else{"+
				"  printy(\"No manual entry for \"+args[0]+\"\\n\")"+
				"}"
			},
			"termy": {
				"man":"Termy is a web-terminal.\n"+
				 "Features (so far):\n -When you press enter, it remembers (check out with up & down keys).\n"+
				 " -Left and right buttons are functional too.\n"+
				 " -Delete and Backspace also working.\n"+
				 " -Enter is working too.\n"+
				 " -It automaticly goes down when you type something (or press Enter & exec command)\n",
				"com":""
			},
			"help": {
				"man":"Displays all possible commands.",
				"com":"var commands = listFolder(\"A:/commands\");"+
						"var maxLen = Math.max.apply(Math, commands.map(function (el) { return el.length }));"+
						"var spacesMin = 4;"+
						"var spacesMax = maxLen+spacesMin;"+
						"commands.forEach(function(e){"+
						"var spaces = \"\";var man=\"\";"+
						"if(exists('A:/commands/'+e+'/man')){"+
						"man = readFile('A:/commands/'+e+'/man').split('\\n')[0];"+
						"}"+
						"for(var i=0;i<spacesMax-e.length;i++) spaces+=\" \";"+
						"if(true){printy('<c 14>'+e+'</c>'+spaces+man+\"\\n\");}"+
						"});",
			},
			"exit": {
				"man":"Tries to exit, fails.",
				"com":"printy(\"Cannot exit.\\n\")",
			},
			"whoami": {
				"man":"Let the termy question its own existence.",
				"com":"printy('admin of maria console powered by CineFlix.\\n\\n');"
			}
		}
	}
};

var user = "<c 12>admin</c><c 1>@</c><c 15>localhost</c>";
var path = "~";
var type = "#";

var pre = user+":"+path+type+" "
var imlecpos = 0;
var commandlist = [""];
var nthCom = 0;

function colorizeOutput(){
	var look = ["b","c"];
	look.forEach(function(e){
		$(".console "+e).each(function(){
			for(var i=0;i<16;i++){
				if($(this).attr(i.toString())===""){
					$(this).addClass(e+i);
				}
			}
		});
	});
}

String.prototype.replaceAll = function(search, replacement) {
    var target = this;
    return target.replace(new RegExp(search, 'g'), replacement);
};

function isPrintable(keycode){
    var valid = 
        (keycode > 47 && keycode < 58)   || // number keys
        keycode == 32 || keycode == 13   || // spacebar & return key(s) (if you want to allow carriage returns)
        (keycode > 64 && keycode < 91)   || // letter keys
        (keycode > 95 && keycode < 112)  || // numpad keys
        (keycode > 185 && keycode < 193) || // ;=,-./` (in order)
        (keycode > 218 && keycode < 223);   // [\]' (in order)

    return valid;
}

function printy(){
	var args = arguments;
    for(var i=0; i<args.length; i++){
        $(".content").append(args[i].replaceAll("\n","<br />"));
    }
}

function eoF(){
	$(".nline").append(pre);
	$(".imlec").addClass("active");
	colorizeOutput();
}

printy("Linux localhost 5.10.0-13-amd64 #1 SMP Debian 5.10.106-1 (2022-03-17) x86_64\n\n");
printy("The programs included with the Debian GNU/Linux system are free software; the exact distribution terms for each program are described in the individual files in /usr/share/doc/copyright.\n\n");
printy("Debian GNU/Linux comes with ABSOLUTELY NO WARRANTY, to the extentpermitted by applicable law.\n\n");
printy("Last update: Tue Jun 2022 from 223.216.129.246\n\n");
printy("Localhost allow full 'ufw' && apache2 for more information type --ufw\n\n");
printy("User: admin@locahost >> IP: 223.167.45.233\n\n");
printy("Private IP: 45.233.69.136 && SSH Protected\n\n");
printy("Type command 'help' for get command informations.\n\n");
eoF();

$(".console").focus(function(){
})

/*
$(".console").contextmenu(function(e){
    event.preventDefault();
    document.execCommand('copy');
})
*/

function guncelle(){
	$(".prompt").html("<c 2>"+commandlist[nthCom].substring(0, imlecpos) +"<p class=\"imlec\">"+(commandlist[nthCom]+'\xa0').substring(imlecpos, imlecpos+1)+"</p>"+ commandlist[nthCom].substring(imlecpos+1, commandlist[nthCom].length+1)+"</c>");
	colorizeOutput();
}

function execSpesific(program){
	var commands = listFolder("A:/commands/");
	var command = program.split(" ")[0];
	if(commands.indexOf(command)!==-1){
		var splitted = program.split(" ");
		var args = eval("[\""+splitted.splice(1,splitted.length).join("\",\"")+"\"]");
		try{
			openFile("A:/commands/"+command+"/com", args);
		}catch(e){}
	}else{
		printy("Command not found. Type `help' to see all commands.\n\n");
	}
	$(".console").scrollTop($(".content").height());
}

function exec(){
	var commands = listFolder("A:/commands/");
	var command = commandlist[nthCom].split(" ")[0];
	if(commands.indexOf(command)!==-1){
		var splitted = commandlist[nthCom].split(" ");
		var args = eval("[\""+splitted.splice(1,splitted.length).join("\",\"")+"\"]");
		try{
			openFile("A:/commands/"+command+"/com", args);
		}catch(e){}
	}else{
		var err = "Command not found. Type `help' to see all commands.";
		printy(err.fontcolor( "red" ));
	}
	commandlist.push("");
	nthCom = commandlist.length-1;
	//go bottom
	$(".console").scrollTop($(".content").height());
}

$(".console").bind("paste", function(e){
   // access the clipboard using the api
   var pastedData = e.originalEvent.clipboardData.getData('text');
   console.log(pastedData);
	commandlist[commandlist.length-1] = commandlist[commandlist.length-1].substring(0, imlecpos)+pastedData+commandlist[commandlist.length-1].substring(imlecpos, commandlist[commandlist.length-1].length);
	imlecpos += pastedData.length;
	nthCom = commandlist.length-1;
	guncelle();
	
} );

$(".console").keydown(function(e){
	$(".console").scrollTop($(".content").height());
	if(nthCom!=commandlist.length-1 && e.keyCode!=38 && e.keyCode!=40){
		commandlist[commandlist.length-1] = commandlist[nthCom];
		nthCom = commandlist.length-1;
	}
	
	if(isPrintable(e.keyCode) && e.key.length==1){
		if(e.ctrlKey === false){
			commandlist[commandlist.length-1] = commandlist[commandlist.length-1].substring(0, imlecpos)+e.key+commandlist[commandlist.length-1].substring(imlecpos, commandlist[commandlist.length-1].length);
			imlecpos++;
			guncelle();
		}
	}else if(e.keyCode==8){
		if(imlecpos>0){
			imlecpos--;
			commandlist[commandlist.length-1] = commandlist[commandlist.length-1].substring(0, imlecpos) + commandlist[commandlist.length-1].substring(imlecpos+1, commandlist[commandlist.length-1].length+1);
			guncelle();
		}
	}else if(e.keyCode==46){
		if(imlecpos<commandlist[commandlist.length-1].length){
			commandlist[commandlist.length-1] = commandlist[commandlist.length-1].substring(0, imlecpos) + commandlist[commandlist.length-1].substring(imlecpos+1, commandlist[commandlist.length-1].length+1);
			guncelle();
		}
	}else if(e.keyCode==37){
		if(imlecpos>0){
			imlecpos--;
		}
		guncelle();
	}else if(e.keyCode==39){
		if(imlecpos<commandlist[commandlist.length-1].length){
			imlecpos++;
		}
		guncelle();
	}else if(e.keyCode==13){
		if(commandlist[commandlist.length-1]){
			printy(pre+"<c 2>"+commandlist[commandlist.length-1]+"</c>"+"\n");
			exec();
			commandlist[commandlist.length-1] = "";
			imlecpos = 0;
			guncelle();
		}
	}else if(e.keyCode==40){
		e.preventDefault();
		if(nthCom<commandlist.length-1){
			nthCom++;
		}else{
			nthCom=0;
		}
		imlecpos = commandlist[nthCom].length;
		guncelle();
	}else if(e.keyCode==38){
		e.preventDefault();
		if(nthCom>0){
			nthCom--;
		}else{
			nthCom=commandlist.length-1;
		}
		imlecpos = commandlist[nthCom].length;
		guncelle();
	}
});

function listFolder(path){
	if(isFolder(path)){
		return Object.keys(pathParser(path));
	}
	return false;
}

function evalFile(path){
	if(isFile(path)){
		return eval(pathParser(path));
	}
	return false;
}

function readFile(path){
	if(isFile(path)){
		return pathParser(path);
	}
	return false;
}

function getExtension(path){
	var cleanedString = path.endsWith("/") ? path.slice(0, -1) : path;
	if(isFile(path)){
		return cleanedString.substr(cleanedString.lastIndexOf(".")+1, cleanedString.length);
	}
	return "";
}

function pathParser(path) {
	//For Everything
	var cleanedString = path.endsWith("/") ? path.slice(0, -1) : path;
	cleanedString = cleanedString.startsWith("/")
		? cleanedString.slice(1, cleanedString.length)
		: cleanedString;
	return cleanedString !== ""
		? eval('tree["' + cleanedString.replaceAll("/", '"]["') + '"]')
		: eval('tree');
}

function isEmpty(path) {
	//For Folders
	if(exists(path)){
		if(isFolder(path)){
			return pathParser(path)==={};
		}else{
			return pathParser(path)==="";
		}
	}
	return true;
}

function isFile(path){
	//For Folders
	return typeof pathParser(path) === "string";
}

function isFolder(path){
	//For Folders
	return typeof pathParser(path) === "object";
}

function exists(path) {
	//For Everything
	return typeof pathParser(path) === "object" || typeof pathParser(path) === "string";
}

function createFolder(path, override=0) {
	//For Folders
	var cleanedString = path.endsWith("/") ? path.slice(0, -1) : path;
	var mainPath = cleanedString.substr(0, cleanedString.lastIndexOf("/"));
	if (exists(mainPath)) {
		console.log("creating folder...");
		if((exists(path) && override) || !exists(path)){
			pathParser(mainPath)[cleanedString.substr(cleanedString.lastIndexOf("/")+1, cleanedString.length)] = {};
			console.log("created!");
		}else{
			console.log("file/folder already exists");
		}
	} else {
		console.log("parent directory not found");
	}
	
}


  // Getting the time and date and post it depending on what you request for
  var getTimeAndDate = function(postTimeDay){
    var timeAndDate = new Date();
    var timeHours = timeAndDate.getHours();
    var timeMinutes = timeAndDate.getMinutes();
    var dateDay = timeAndDate.getDate();
    console.log(dateDay);
    var dateMonth = timeAndDate.getMonth() + 1; // Because JS starts counting months from 0
    var dateYear = timeAndDate.getFullYear(); // Otherwise we'll get the count like 98,99,100,101...etc.

    if (timeHours < 10){ // if 1 number display 0 before it.
      timeHours = "0" + timeHours;
    }

    if (timeMinutes < 10){ // if 1 number display 0 before it.
      timeMinutes = "0" + timeMinutes;
    }

    var currentTime = timeHours + ":" + timeMinutes;
    var currentDate = dateDay + "/" + dateMonth + "/" + dateYear;

    if (postTimeDay == "time"){
      addTextToResults(currentTime);
    }
    if (postTimeDay == "date"){
      addTextToResults(currentDate);
    }
  }



function createFile(path, content="", override=0) {
	//For Folders
	var cleanedString = path.endsWith("/") ? path.slice(0, -1) : path;
	var mainPath = cleanedString.substr(0, cleanedString.lastIndexOf("/"));
	if (exists(mainPath) && isFolder(mainPath)) {
		console.log("creating file...");
		if((exists(path) && override) || !exists(path)){
			pathParser(mainPath)[cleanedString.substr(cleanedString.lastIndexOf("/")+1, cleanedString.length)] = content;
			console.log("created!");
		}else{
			console.log("file/folder already exists");
		}
	} else {
		console.log("parent directory not found");
	}
}

String.prototype.replaceAll = function(search, replacement) {
	var target = this;
	return target.replace(new RegExp(search, "g"), replacement);
};

function openFile(path, args=[]){
	eval("var args=[\""+args.join("\",\"")+"\"];\n"+pathParser(path));
}