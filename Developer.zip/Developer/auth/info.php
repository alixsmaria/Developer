<?php 
session_start();
require_once("config.php");

$nam = $_SESSION['name'];
$mob = $_SESSION['mobile'];
$tok = $_SESSION['token'];

$client_id = substr(str_shuffle("0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"), -6);

$password = substr(str_shuffle("0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz!@#$%^&*()?/"), -10);
$s_password = md5($password);

$message = "Hi, $nam welcome to developer console. Start your development with python, javascript, PHP, solidity and many more. Your dev console id: $client_id & password: $password don't share your senstive details with anyone. --Team@Maria";

$sql = "INSERT INTO auth (client_id, name, mobile, password, token) VALUES ('$client_id', '$nam', '$mob', '$s_password', '$tok')";
     if (mysqli_query($conn, $sql)) {
        echo "New record has been added successfully !";
     } else {
        echo "Error: " . $sql . ":-" . mysqli_error($conn);
     }
     mysqli_close($conn);

require_once 'vendor/autoload.php'; 
 
use Twilio\Rest\Client; 
 
$sid    = "ACa908a4c044bb8d9b268db87243488411"; 
$token  = "ed1abcdc55d0b23d4c839f3973b952fd"; 
$twilio = new Client($sid, $token); 
 
$message = $twilio->messages 
                  ->create("+91{$mob}" ,// to 
                           array(  
                               "messagingServiceSid" => "MGae2fce7eb26489fa6169920b86c3fbe7",      
                               "body" => "$message" 
                           ) 
                  ); 
 
header("Location: index.html");


?>