<?php 

session_start();
require_once("config.php");

$name = $_SESSION['name'];
$id = $_SESSION['unique-id'];
$mobile = $_SESSION['mobile'];
$token = $_SESSION['token'];

if(isset($_POST['auth'])) {

    $otp = mysqli_real_escape_string($conn, $_POST['otp']);

    $query = mysqli_query($conn, "SELECT id FROM users WHERE otp = '$otp'");

    if (mysqli_num_rows($query) > 0 ) {
        $row = mysqli_fetch_assoc($query);
        $_SESSION['name'] = $name;
        $_SESSION['mobile'] = $mobile;
        $_SESSION['token'] = $token;
        header("Location: info.php");
    } else {
        echo "OTP didn't matched try again!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>OTP | Verification</title>
    <link rel="stylesheet" href="css/otp.css">
</head>
<body>
    <div class="container">
        <form action="" method="post">
            <h3 class="text">We have sent an OTP to your mobile</h3>
            <input type="text" name="otp" placeholder="Enter your 6 digit OTP" class="input" minlength="6" maxlength="6" required/>
            <button type="submit" name="auth" class="btn">Authenticate</button>
        </form>
    </div>
</body>
</html>

