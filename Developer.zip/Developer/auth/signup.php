<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
	<link rel="stylesheet" href="css/style.css">
	<title>Responsive Login And Register Form</title>
</head>
<body>
	
	<div class="container">
		<form action="authenticate.php" method="POST" class="login active">
			<h2 class="title">Register your self</h2>
			<div class="form-group">
				<label for="email">Name</label>
				<div class="input-group">
					<input type="text" name="name" id="name" placeholder="Enter Your full name">
					<i class='bx bx-user-circle'></i>
				</div>
			</div>
			<div class="form-group">
				<label for="password">Mobile</label>
				<div class="input-group">
					<input type="tel" name="mobile" pattern=".{10,}" id="tel" placeholder="Enter your mobile number">
					<i class='bx bx-mobile-alt' ></i>
				</div>
				<span class="help-text">Don't share your senstive data with anyone</span>
			</div>
			<button type="submit" name="authenticate" class="btn-submit">Authenticate</button>
		</form>
	</div>

	<script src="js/script.js"></script>
</body>
</html>

<?php 

if (isset($_POST['authenticate'])) {

 header("Location: authenticate.php");
}

?>