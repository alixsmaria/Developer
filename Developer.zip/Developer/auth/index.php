<?php 

session_start();
require_once("config.php");

if(isset($_SESSION["user_id"])) {
	header('Location: ../client');
}

if(isset($_POST['login'])) {

    $uid = mysqli_real_escape_string($conn, $_POST['uid']);
	$password = mysqli_real_escape_string($conn, md5($_POST['password']));

    $query = mysqli_query($conn, "SELECT id FROM auth WHERE client_id = '$uid' AND password='$password'");

    if (mysqli_num_rows($query) > 0 ) {
        $row = mysqli_fetch_assoc($query);
		$_SESSION['user_id'] = $row['id'];
        $_SESSION['name'] = $row['name'];
        header("Location: ../client");
    } else {
        echo "<script>alert('User id & password are wrong');";
    }
}
mysqli_close($conn);

?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
	<link rel="stylesheet" href="css/style.css">
	<title>Responsive Login And Register Form</title>
</head>
<body>
	
	<div class="container">
		<form action="#" class="login active" method="POST" autocomplete="off">
			<h2 class="title">Login with your console</h2>
			<div class="form-group">
				<label for="email">UID</label>
				<div class="input-group">
					<input type="text" id="text" name="uid" placeholder="Enter Your User id" required>
					<i class='bx bx-envelope'></i>
				</div>
			</div>
			<div class="form-group">
				<label for="password">Password</label>
				<div class="input-group">
					<input type="password" pattern=".{8,}" id="password" name="password" placeholder="Your password" required>
					<i class='bx bx-lock-alt' ></i>
				</div>
				<span class="help-text">Don't share your password with anyone</span>
			</div>
			<button type="submit" class="btn-submit" name="login">Login</button>
		</form>
	</div>

	<script src="js/script.js"></script>
</body>
</html>