<?php 

$my_rand_strng = substr(str_shuffle("0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"), -6);

echo $my_rand_strng;

?>