

<?php
ini_set ('error_reporting', E_ALL);
ini_set ('display_errors', '1');
error_reporting (E_ALL|E_STRICT);

$conn = mysqli_init();
mysqli_options ($conn, MYSQLI_OPT_SSL_VERIFY_SERVER_CERT, true);

$conn->ssl_set('', '', 'key/mysql-ca-certificate.crt', NULL, NULL);
$link = mysqli_real_connect ($conn, 'lin-3380-3263-mysql-primary.servers.linodedb.net', 'linroot', 'n^oCIdcR5a72lSEi', 'Developer', 3306, NULL, MYSQLI_CLIENT_SSL);
if (!$link)
{
    die ('Connect error (' . mysqli_connect_errno() . '): ' . mysqli_connect_error() . "\n");
} else {

}
?>

