<?php 
 
 session_start();
 require_once("config.php");

$unique_id = mt_rand(100000000, 999999999);

$name = $_POST['name'];
$mobile = $_POST['mobile'];

$otp = mt_rand(100000, 999999);

$str = rand();
$token = hash("sha256", $str);
$message = "Welcome $name your OTP is $otp. Valid for 10 minutes. Don't share your senstive data with anyone. we never asked for your informations about your privacy. --Team@MARIA";

$sql = "INSERT INTO users (unique_id, name, mobile, otp, token) VALUES ('$unique_id','$name','$mobile', '$otp', '$token')";
     if (mysqli_query($conn, $sql)) {
        $_SESSION['name'] = $name;
        $_SESSION['mobile'] = $mobile;
        $_SESSION['token'] = $token;
        echo "New record has been added successfully !";
     } else {
        echo "Error: " . $sql . ":-" . mysqli_error($conn);
     }
     mysqli_close($conn);

require_once 'vendor/autoload.php'; 
 
use Twilio\Rest\Client; 
 
$sid    = "ACa908a4c044bb8d9b268db87243488411"; 
$token  = "ed1abcdc55d0b23d4c839f3973b952fd"; 
$twilio = new Client($sid, $token); 
 
$message = $twilio->messages 
                  ->create("+91{$mobile}" ,// to 
                           array(  
                               "messagingServiceSid" => "MGae2fce7eb26489fa6169920b86c3fbe7",      
                               "body" => "$message" 
                           ) 
                  ); 
 
header("Location: verification.php");


?>